#pragma once
#include "AnimationWindow.h"

// Abstrakt klasse. Arvende konkrete klasser må implementere funksjonen draw()
// som tegner former i vinduet de skal bli vist i.
class Emoji
{
public:
    virtual void draw(AnimationWindow& win) = 0;
    virtual ~Emoji(){}; //destruktør
};


class Face : public Emoji
{
    protected:
        Point c;
        int r;
    public:
        Face(Point cc, int rr) : c{cc}, r{rr} {}
        virtual void draw(AnimationWindow& win) override
        {
           win.draw_circle(c, r, Color::yellow); 
        }
        
};

class EmptyFace : public Face
{
    public:
        EmptyFace(Point c, int r) : Face(c, r) {}
        virtual void draw(AnimationWindow& win) override
        {
            Point leye = {c.x-40,c.y-20};
            Point reye = {c.x+40,c.y-20};
            
            win.draw_circle(c,r,Color::yellow);
            win.draw_circle(leye, r/4, Color::white);
            win.draw_circle(reye, r/4, Color::white);
            win.draw_circle(leye, r/8, Color::blue);
            win.draw_circle(reye, r/8, Color::blue);
        }


};

class SmileyFace : public Face
{
    public:
        SmileyFace(Point c, int r) : Face(c, r) {}
        virtual void draw(AnimationWindow& win) override
        {
            Point leye = {c.x-40,c.y-20};
            Point reye = {c.x+40,c.y-20};
            
            win.draw_circle(c,r,Color::yellow);
            win.draw_circle(leye, r/4, Color::white);
            win.draw_circle(reye, r/4, Color::white);
            win.draw_circle(leye, r/8, Color::blue);
            win.draw_circle(reye, r/8, Color::blue);
            win.draw_arc({c.x,c.y+40},80,40,180,360,Color::black);
        }
};

class SadFace : public Face
{
    public:
        SadFace(Point c, int r) : Face(c, r) {}
        virtual void draw(AnimationWindow& win) override
        {
            Point leye = {c.x-40,c.y-20};
            Point reye = {c.x+40,c.y-20};
            
            win.draw_circle(c,r,Color::yellow);
            win.draw_circle(leye, r/4, Color::white);
            win.draw_circle(reye, r/4, Color::white);
            win.draw_circle(leye, r/8, Color::blue);
            win.draw_circle(reye, r/8, Color::blue);
            win.draw_arc({c.x,c.y+40},80,40,0,180,Color::black);
        }
};

class AngryFace : public Face
{
    public:
        AngryFace(Point c, int r) : Face(c, r) {}
        virtual void draw(AnimationWindow& win) override
        {
            Point leye = {c.x-40,c.y-20};
            Point reye = {c.x+40,c.y-20};
            
            win.draw_circle(c,r,Color::yellow);
            win.draw_circle(leye, r/4, Color::white);
            win.draw_circle(reye, r/4, Color::white);
            win.draw_circle(leye, r/8, Color::blue);
            win.draw_circle(reye, r/8, Color::blue);
            win.draw_arc({c.x,c.y+40},80,20,0,180,Color::black);
            win.draw_line({leye.x-r/8, leye.y-3*r/5},{leye.x+r/4, leye.y-r/4},Color::black);
            win.draw_line({reye.x+r/8, reye.y-3*r/5},{reye.x-r/4, reye.y-r/4},Color::black);
        }
};

class WinkingFace : public Face
{
    public:
        WinkingFace(Point c, int r) : Face(c, r) {}
        virtual void draw(AnimationWindow& win) override
        {
            Point leye = {c.x-40,c.y-20};
            Point reye = {c.x+40,c.y-20};
            
            win.draw_circle(c,r,Color::yellow);
            win.draw_arc({leye.x,leye.y+10}, r/2,r/2,0,180, Color::black);
            win.draw_circle(reye, r/4, Color::white);
            //win.draw_circle(leye, r/8, Color::blue);
            win.draw_circle(reye, r/8, Color::blue);
            win.draw_arc({c.x,c.y+40},80,40,180,360,Color::black);
            
        }
};

class SurprisedFace : public Face
{
    public:
        SurprisedFace(Point c, int r) : Face(c, r) {}
        virtual void draw(AnimationWindow& win) override
        {
            Point leye = {c.x-40,c.y-20};
            Point reye = {c.x+40,c.y-20};
            
            win.draw_circle(c,r,Color::yellow);
            win.draw_circle(leye, r/4, Color::white);
            win.draw_circle(reye, r/4, Color::white);
            win.draw_circle(leye, r/8, Color::blue);
            win.draw_circle(reye, r/8, Color::blue);
            win.draw_arc({c.x,c.y+40},80,40,0,360,Color::black);
        }
};