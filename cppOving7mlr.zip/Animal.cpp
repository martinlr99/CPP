#include "Animal.h"
#include "std_lib_facilities.h"

void testAnimal()
{
    vector<unique_ptr<Animal>> vek;
    
    vek.emplace_back(new Cat("Nils", 45));
    vek.emplace_back(new Dog("Pelle", 2));
    //vek.emplace_back(new Animal("Froggy", 5));
    //vek.emplace_back(new Animal("Turtle", 3));
    int str = vek.size();
    cout << "The vec has " << str << " elements" << endl;
    for (int i=0; i < str; i++)
    {
        cout << vek.at(i) -> toString() << endl; 
    } 

    /* Animal a = Animal("Frog",3);
    Cat b = Cat("Nils",45);
    cout << a.toString() << "  " << b.toString();  */
}