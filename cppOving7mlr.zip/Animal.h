#pragma once
#include "std_lib_facilities.h"

// 1a) public: alle andre kan bruke variabelen
// protected: variabelen kan brukes i visse tilfeller
// private: kun egen klasse som kan bruke variabelen

class Animal
{
    protected:
        string name;
        int age;
    public:
        Animal(string n, int a) : name{n}, age{a} {}
        virtual ~Animal(){}

        virtual string toString() = 0
        {
            string tekst = "Animal: " + name + ", " + to_string(age);
            return tekst; 
        }
};

class Cat : public Animal
{
    public:
        Cat(string n, int a) : Animal(n,a) {}

        virtual string toString()
        {
            string tekst = "Cat: " + name + ", " + to_string(age);
            return tekst;
        }

};

class Dog : public Animal
{
    public:
        Dog(string n, int a) : Animal(n, a) {}

        virtual string toString()
        {
            string tekst = "Dog: " + name + ", " + to_string(age);
            return tekst;
        }
    
};

void testAnimal();