#include "AnimationWindow.h"
#include "Emoji.h"
#include "Animal.h"

// Definer størrelse på vindu og emoji
constexpr int xmax = 1000;
constexpr int ymax = 600;
constexpr int emojiRadius = 50;

int main()
{

	const Point tl{100, 100};
	const string win_label{"Emoji factory"};
	AnimationWindow win{tl.x, tl.y, xmax, ymax, win_label};
	//Face f = Face({500,250},100);
	//f.draw(win);
	//EmptyFace e = EmptyFace({450,150},100);
	//e.draw(win);
	SmileyFace smiley = SmileyFace({200,150},100);
	smiley.draw(win);
	SadFace sad = SadFace({450,150},100);
	sad.draw(win);
	AngryFace ang = AngryFace({700,150},100);
	ang.draw(win);
	WinkingFace w = WinkingFace({200,400},100);
	w.draw(win);
	SurprisedFace s = SurprisedFace({450, 400},100);
	s.draw(win);
	

	/* TODO:
	 *  - initialiser emojiene
	 *  - Tegn emojiene til vinduet
	 */

	win.wait_for_close(); 
	
	//testAnimal();

	
}
