#include "Emoji.h"
